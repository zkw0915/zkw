#include<iostream>
using namespace std;

int main()
{
    int n, Q;
    cin >> n >> Q;
    int data[100];
    for (int i = 0; i < n; i++)
        cin >> data[i];//��������
    int Q_data[100];
    for (int i = 0; i < Q; i++)//�۰���ҷ���
    {
        int low = 0;
        int high = n - 1;
        int mid;
        cin >> Q_data[i];
        if (Q_data[i] <= data[low])
            cout<<data[low]<<endl;

        else if (Q_data[i] >= data[high])
            cout<<data[high]<<endl;

        else
        {
            while (low <= high)
            {
                mid = (low + high) / 2;
                if (Q_data[i] <= data[mid])
                {
                    high = mid - 1;
                    if (Q_data[i] > data[high])
                    {
                        cout << data[mid]<<endl;
                        break;
                    }
                }
                else if (Q_data[i] > data[mid])
                {
                    low = mid + 1;
                    if (Q_data[i] <= data[low])
                    {
                        cout << data[low]<<endl;
                        break;
                    }
                  
                }
            }//while
        }//else

    }//for
    return 0;
}//main