/*******************************************************************************
* FileName:         DBLinkList.cpp
* Author:           �ſ�Ϊ
* Student Number:   3019244121
* Date:             2020/03/04 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #3
*******************************************************************************/

#include "DBLinkList.h"
#include <cstddef>
#include<iostream>

DBLinkList::DBLinkList() {
	head = tail = NULL;
	len = 0;
}
DBLinkList::~DBLinkList() {
	for (int i = 0; i < len; i++)
	{
		DBNode* temp;
		temp = head;
		head = head->nxt;
		delete temp;
	}
}

void DBLinkList::insert(int data, int location) {
	DBNode* ins = new DBNode;
	ins->value = data;
	if (location == 0)
	{
		ins->nxt = head;
		ins->pre = NULL;
		head = ins;
		if (len == 0)
		{
			tail = ins;
			ins->nxt = NULL;
		}
		else
		{
			ins->nxt->pre = ins;
		}
	}
	else {
		DBNode* temp = head;
		for (int i = 0; i < location-1; i++)
		{
			temp = temp->nxt;
		}
		if (location == len)
		{
			ins->pre = temp;
			ins->nxt = NULL;
			temp->nxt = ins;
			tail = ins;
		}
		else
		{
			ins->pre = temp;
			ins->nxt = temp->nxt;
			temp->nxt = ins;
		}
	}
	len++;
	return;
}

void DBLinkList::remove(int location) {
	//tou
	if (location == 0)
	{
		head = head->nxt;
		head->pre = NULL;
		len--;
	}
	//wei
	if (location == len - 1)
	{
		tail = tail->pre;
		tail->nxt = NULL;
		len--;
	}
	//zhong
	if (location > 0 && location < len - 1)
	{
		DBNode* a;
		a = head;
		for (int i = 0; i < location;i++)
		{
			a = a->nxt;
		}
		a->pre->nxt = a->nxt;
		a->nxt->pre = a->pre;
		len--;
	}
}

int DBLinkList::length() {
	return len;
}

int DBLinkList::getData(int location) {
	DBNode* temp;
	temp = head;
	for (int i = 0; i < location; i++)
	{
		temp = temp->nxt;
	}
	int result = temp->value;
	return result;
	temp = NULL;
}

void DBLinkList::bubbleSort() {
	DBNode* p;
	p = head;
	for (int i = 0; i < len-1; i++)
	{
		DBNode* q;
		q = head;
		int temp = 0;
		for (int j = i+1; j < len; j++)
		{
			q = q->nxt;
			if (p->value > q->value)
			{
				temp = p->value;
				p->value = q->value;
				q->value = temp;
			}
		}
		p = p->nxt;
	}
}