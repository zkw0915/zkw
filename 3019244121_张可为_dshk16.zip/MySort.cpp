/*******************************************************************************
* FileName:         MySort.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2019/05/27 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #16
*******************************************************************************/

#include "MySort.h"

void MySort::bubbleSort(int* arr, int len) {
	int i = 0;
	int exchange = 1;
	while (i < len && exchange)
	{
		exchange = 0;  //��־��Ϊ0���ٶ�δ����
		for (int j = len - 1; j >= i; j--)
		{
			if (arr[j - 1] > arr[j])//����
			{
				int temp = arr[j];
				arr[j] = arr[j - 1];
				arr[j - 1] = temp;//����
				exchange = 1;
			}//if
		}//for
		i++;
	}//while
}


void MySort::quickSort(int* arr, int len) {
	QSort(arr, 0, len - 1);
}

void MySort::QSort(int* arr, int low, int high)
{
	int i = low;
	int j = high;
	int pivotkey = arr[i];
	while (i < j)//�����ݹ�����
	{
		while (i < j)
		{
			while (i < j && arr[j] >= pivotkey)
				j--;
			arr[i] = arr[j];
			while (i < j && arr[i] <= pivotkey)
				i++;
			arr[j] = arr[i];
		}
		arr[i] = pivotkey;//�ѻ�׼���������low��Ӧ��λ����
		QSort(arr, low, i - 1);
		QSort(arr, i + 1, high);
	}
}

void MySort::heapSort(int* arr, int len) {
	for (int i = len / 2 - 1; i >= 0; i--)
		heapAdjust(arr, i, len);
	for (int i = len - 1; i >= 0; i--)
	{
		int temp = arr[0];
		arr[0] = arr[i];
		arr[i] = temp;
		heapAdjust(arr, 0, i);
	}
}

void MySort::heapAdjust(int* arr, int s, int size)
{
	int temp = arr[s];
	for (int i = 2 * s + 1; i < size; i = 2 * i + 1)
	{
		if (i < size - 1 && arr[i] < arr[i + 1])
			i++;
		if (temp >= arr[i])
			break;
		arr[s] = arr[i];
		s = i;
	}
	arr[s] = temp;
}
