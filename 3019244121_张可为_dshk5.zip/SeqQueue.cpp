#include "SeqQueue.h"



SeqQueue::SeqQueue() {
	SeqList = new int[MAX_ELEMENTS];
	first=rear= 0;
}
SeqQueue::~SeqQueue() {
	delete SeqList;
}
void SeqQueue::pop_front() {
	if (rear == 0||first>rear)
		return;
	else
		first++;
}
void SeqQueue::push_back(int data) {
	SeqList[rear] = data;
	rear++;
}
int SeqQueue::front() const {
	return SeqList[first];
}