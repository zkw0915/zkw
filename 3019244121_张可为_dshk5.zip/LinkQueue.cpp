#include "LinkQueue.h"
#include <cstddef>

LinkQueue::LinkQueue() {
	first = rear = NULL;
}

LinkQueue::~LinkQueue() {
	    for (int i = 0; i < length ; i++)
		{
			StackNode* temp;
			temp = first;
			first = first->next;
			delete temp;
			temp = NULL;
		}
}

void LinkQueue::push_back(int data) {
	if (length == 0)
	{
		first = new StackNode;
		first->value = data;
		rear = first;
		first->next = NULL;
	}
	else
	{
		StackNode* temp=new StackNode;
		rear->next = temp;
		rear = temp;
		rear->value = data;
		rear->next = NULL;
	}
	length++;
}

void LinkQueue::pop_front() {
	if (first == rear)
		return;
	else
	{
		StackNode* temp = first;
		first = temp->next;
		delete temp;
		temp = NULL;
		length--;
	}
}


int LinkQueue::front() const {
	return first->value;
}