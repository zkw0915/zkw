/*******************************************************************************
* FileName:         myHash.cpp
* Author:           �ſ�Ϊ
* Student Number:   3019244121
* Date:             2020/05/20 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #15
*******************************************************************************/

#include "myHash.h"
#define p 997//С��1000���������


MyHash::MyHash(int max_element) {
	max = max_element;
	arr = new HashTable[max];
	for (int i = 0; i < max; i++)
	{
		arr[i].key = 0;
	}
}

MyHash::~MyHash() {
	delete[] arr;
}

void MyHash::setvalue(int key, int value) {
	int key_p = key % p;
	if (arr[key_p].key == 0)
	{
		arr[key_p].data = value;
		arr[key_p].key = key;
	}
	else
	{
		while (arr[key_p].key != 0)
		{
			key_p--;
		}
		arr[key_p].key = key;
		arr[key_p].data = value;
	}
}

int MyHash::getvalue(int key) {
	for (int i = 0; i < max; i++)
	{
		if (arr[i].key == key)
			return arr[i].data;
	}
}