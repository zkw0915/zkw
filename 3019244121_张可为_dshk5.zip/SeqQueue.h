/*******************************************************************************
* FileName:         SeqStack.h
* Author:           �ſ�Ϊ
* Student Number:   3019244121
* Date:             2020/03/11 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #5
*                   ����ɵ�SeqQueue.h�ļ�
*******************************************************************************/

#ifndef SEQQUEUE_H
#define SEQQUEUE_H

#include "MyQueue.h"

class SeqQueue : public MyQueue {
private:
    const static int MAX_ELEMENTS = 100;
    int* SeqList;   
    int rear,first;    
public:
    SeqQueue();
    virtual ~SeqQueue();
    void pop_front();
    void push_back(int data);
    int front() const;
};
#endif#pragma once
