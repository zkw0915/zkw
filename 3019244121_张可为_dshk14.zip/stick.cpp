#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int* len = new int[n];
	for (int i = 0; i < n; i++)
	{
		cin >> len[i];
	}
	sort(len, len + n);
	int num = 0;
	for (int i = 0; i < n - 2; i++)
	{
		int first = len[i];
		for (int j = i + 1; j < n - 1; j++)
		{
			int second = len[j];
			for (int m = j + 1; m < n; m++)
			{
				int third = len[m];
				if (first + second > third&& first + third > second&& second + third > first)
					num++;
			}//for3
		}//for2
	}//for1
	cout << num << endl;
	return 0;
}