/*******************************************************************************
* FileName:         Graph.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2020/04/29 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #11
*******************************************************************************/

#include "Graph.h"
#include <cstddef>

Graph::Graph(int max_v) {
	num = max_v;
	data = new VexNode[max_v + 1];
	arr = new int[num];
}

Graph::~Graph() {
	for (int i = 1; i <= num; i++) {
		if (data[i].outdegree == 0)
			continue;

		EdgeNode* temp = data[i].first;
		while (temp->next != nullptr) {
			EdgeNode* toDelete = temp;
			temp = temp->next;
			delete toDelete;
		}
		delete temp;
	}//for
	delete[] data;
	delete[] arr;
}

void Graph::addedge(int s, int t, int w) {
	EdgeNode* newEdge = new EdgeNode;
	newEdge->next = nullptr;
	newEdge->dest = t;
	newEdge->weight = w;

	if (data[s].outdegree == 0) {		//��һ��
		data[s].first = newEdge;
	}
	else {
		EdgeNode* temp = data[s].first;
		while (temp->next != nullptr) {
			temp = temp->next;
		}
		temp->next = newEdge;
	}
	data[s].outdegree++;
	data[s].data = s;
	data[t].indegree++;
	data[t].data = t;

}

int Graph::getV() {
	for (int i = 0; i < num + 1; i++)
	{
		if (data[i].indegree != 0 || data[i].outdegree != 0)
			point_Num++;
	}
	return point_Num;
}

int* Graph::topological() {
	/*int j = 0;
	for (int i = 0; i < num + 1; i++)
		arr[i] = 0;
	for (int i = 1; i < num + 1 ; i++)
	{
		if (data[i].indegree == 0)
		{
			arr[j] = i;
			j++;
			EdgeNode* temp = data[i].first;
			while (temp != NULL)
			{
				data[temp->dest].indegree--;
				temp = temp->next;
			}
		}
	}
	return arr;*/

	LinkStack mylist;
	int j = 0;
	for (int i = 1; i < num + 1; i++)
	{
		if (data[i].indegree == 0)
			mylist.push_back(i);
	}
	for (int i = 1; i < num + 1; i++)
	{
		int m = mylist.top();
		arr[j] = m;
		j++;
		mylist.pop();
		EdgeNode* temp = data[m].first;
		while(temp!=NULL)
		{
			int k = temp->dest;
			if (--data[k].indegree == 0)
				mylist.push_back(k);
			temp = temp->next;
		}
	}
	return arr;

}

LinkStack::LinkStack()
{
	head = NULL;
	length = 0;
}

LinkStack::~LinkStack()
{
	for (int i = 0; i < length; i++) {
		StackNode* temp;
		temp = head;
		head = head->next;
		delete temp;
		temp = NULL;
	}
	delete head;
	head = NULL;
}

void LinkStack::push_back(int data)
{
	StackNode* newNode = new StackNode;
	newNode->value = data;
	newNode->next = head;
	head = newNode;
	length++;
}

int LinkStack::top()
{
	if (length == 0)
		return 0;
	else
		return head->value;
}

void LinkStack::pop()
{
	if (length == 0)
		return;
	else {
		StackNode* temp = head;
		head = head->next;
		delete temp;
		temp = NULL;
		length--;
	}
}
