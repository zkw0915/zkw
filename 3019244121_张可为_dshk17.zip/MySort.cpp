/*******************************************************************************
* FileName:         MySort.cpp
* Author:           Your_name
* Student Number:   Student_Number
* Date:             2019/06/03 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #17
*******************************************************************************/

#include "MySort.h"


void mergeSort(int* arr, int len) {
	int* mergearr = new int[len];
	int pri_len = 1;
	while (pri_len < len)
	{
		mergePass(arr, mergearr, pri_len, len);
		pri_len *= 2;
		mergePass(mergearr, arr, pri_len, len);
		pri_len *= 2;
	}
	delete[] mergearr;
}

void merge(int* arr, int* mergearr, int left, int mid, int right)
{
	int i = left;
	int j = mid + 1;
	int k = left;
	while (i <= mid && j <= right)//�����ȽϽ���С�Ĳ���
	{
		if (arr[i] <= arr[j])
		{
			mergearr[k] = arr[i];
			i++;
			k++;
		}
		else
		{
			mergearr[k] = arr[j];
			j++;
			k++;
		}
	}
	while (i <= mid)//��midǰ��ʣ��Ԫ�ز���
	{
		mergearr[k] = arr[i];
		i++;
		k++;
	}
	while (j <= right)//��mid���ʣ��Ԫ�ز���
	{
		mergearr[k] = arr[j];
		j++;
		k++;
	}
}

void mergePass(int* arr, int* mergearr, int length,int n)
{
	int i = 0;
	while (i + 2 * length - 1 <= n - 1)
	{
		merge(arr, mergearr, i, i + length - 1, i + 2 * length - 1);
		i += 2 * length;
	}
	if (i + length <= n - 1)
		merge(arr, mergearr, i, i + length - 1, n - 1);
	else
	{
		for (int j = i; j <= n - 1; j++)
			mergearr[j] = arr[j];
	}
}

void cardSort(int* arr, int len) {
	int maxBits = 1;//�����������Ԫ�ص�λ��
	int curBits, curNum, curBit;//��ǰԪ�ص�λ����curnum�ǵ�ǰԪ��
	int MSBits, LSBits;//MSBits�ǵ�ǰԪ�ص��������λ��LSBit��MSBits����͵�һλ
	int group[10];//group�����洢ĳһλ��Ԫ�صĸ���
	int* result = new int[len];
	int i, j;

	for (int i = 0; i < len; i++)
	{
		curNum = arr[i];
		curBits = 0;
		while (curNum)
		{
			curBits++;
			curNum /= 10;
		}
		maxBits = (curBits > maxBits) ? curBits : maxBits;
	}
	for (i = 0, curBit = 1; i < maxBits; i++, curBit *= 10)
	{
		for (j = 0; j < 10; j++)
			group[j] = 0;
		for (j = 0; j < len; j++) {
			MSBits = arr[j] / curBit;
			LSBits = MSBits % 10;
			group[LSBits]++;
		}

		group[0]--;//�����0��ʼ
		for (j = 1; j < 10; j++)
			group[j] += group[j - 1];//��ǰλΪ0��1����Ԫ���Ǹ������������ֹΪֹ
		for (j = len - 1; j >= 0; j--)
		{
			MSBits = arr[j] / curBit;
			LSBits = MSBits % 10;
			result[group[LSBits]--] = arr[j];
		}

		for (j = 0; j < len; j++)
			arr[j] = result[j];
	}
	delete[] result;
}