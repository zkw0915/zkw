/*******************************************************************************
* FileName:         Graph.cpp
* Author:           �ſ�Ϊ
* Student Number:   3019244121
* Date:             2020/05/06 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #13
*******************************************************************************/

#include "Graph.h"

Graph::Graph(int max_v) {
	num = max_v;
	data = new VexNode[max_v + 1];
	dist = new int[num + 1];
	for (int i = 1; i < num + 1; i++)
	{
		data[i].first = NULL;
		if (i == 1)
			dist[i] = 0;
		else
			dist[i] = -1;
	}
}

Graph::~Graph() {
	for (int i = 1; i <= num; i++) {
		if (data[i].outdegree == 0)
			continue;

		EdgeNode* temp = data[i].first;
		while (temp->next != nullptr) {
			EdgeNode* toDelete = temp;
			temp = temp->next;
			delete toDelete;
		}
		delete temp;
	}//for
	delete[] data;
	delete[] dist;
}

void Graph::addedge(int s, int t, int w) {
	EdgeNode* newEdge = new EdgeNode;
	newEdge->next = nullptr;
	newEdge->dest = t;
	newEdge->weight = w;

	if (data[s].outdegree == 0) {		//��һ��
		data[s].first = newEdge;
	}
	else {
		EdgeNode* temp = data[s].first;
		while (temp->next != nullptr) {
			temp = temp->next;
		}
		temp->next = newEdge;
	}
	data[s].outdegree++;
	data[s].data = s;
	data[t].indegree++;
	data[t].data = t;
}

int Graph::getV() {
	for (int i = 0; i < num + 1; i++)
	{
		if (data[i].indegree != 0 || data[i].outdegree != 0)
			point_Num++;
	}
	return point_Num;
}

int* Graph::dijkstra() {
	const int a = 100;
	int min;
	int v = 1;
	dist = new int[num + 1];//���·����������
	int* S = new int[num + 1];    //���·�����㼯

	for (int i = 0; i < num + 1; i++)
	{
		dist[i] = -1;
		S[i] = 0;
	}//for ��ʼ��dist������S����
	EdgeNode* temp = data[v].first;
	while (temp)
	{
		dist[temp->dest] = temp->weight;
		temp = temp->next;
	}
	S[v] = 1;//������v���뵽����S����ʾ���������·����
	dist[v] = 0;
	int u = 1;
	for (int m = 0; m < num - 1; m++)//�Ӷ���vȷ��n-1��·��
	{
		for (int i = 2; i < num + 1; i++)
		{
			if (dist[i] >= 0 && !S[i])
			{
				min = dist[i];
				u = i;
				break;
			}
		}
		for (int j = 2; j < num + 1; j++)
		{
			if (!S[j] && dist[j] >= 0&& dist[j] < min)
			{
				u = j;
				min = dist[j];
			}
		}
		S[u] = 1;//������u���뼯��S����ʾ���������·����
		EdgeNode* p = data[u].first;
		while (p)
		{
			dist[p->dest] = (p->weight + min < dist[p->dest] || dist[p->dest] == -1) ? (p->weight + min) : dist[p->dest];
			p = p->next;
		}
	}//for
	for (int i = 0; i < num; i++)
	{
		dist[i] = dist[i + 1];
	}
	delete[] S;
	return dist;

}