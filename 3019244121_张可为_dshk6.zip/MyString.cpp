/*******************************************************************************
* FileName:         MyString.cpp
* Author:           �ſ�Ϊ
* Student Number:   3019244121
* Date:             2020/03/18 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #3
*                   ��ɳ̶ȣ�
*                       ��Ҫ˵һ���Լ�д�˶��٣��������Щ����
*******************************************************************************/
#include <cstdio>
#include <cstdlib>
#include<cstring>
#include "MyString.h"


MyString::MyString(const char* str1) {
	len = strlen(str1);
	str = new char[len+1];
	for (int i = 0; i < len; i++)
	{
		str[i] = str1[i];
	}
	str[len] = '\0';
}

MyString::~MyString() {
	delete[] str;
}

int MyString::length() const {
	return len;
}

void MyString::replace(const char* replace, int loc)
{
	if (loc<0 || loc>len)
	{
		return;
	}
	int len1 = strlen(replace);
	if (len1 + loc >= len)
	{
		char* tempptr = str;
		str = new char[loc + len1 + 1];
		str[loc + len1] = '\0';
		len = loc + len1;
		for (int i = 0; i < loc; i++)
		{
			str[i] = tempptr[i];
		}
		for (int i = loc; i < loc + len1; i++)
		{
			str[i] = replace[i - loc];
		}
		delete[] tempptr;
	}
	else
	{
		for (int i = loc; i < loc + len1; i++)
		{
			str[i] = replace[i - loc];
		}
	}
}

int MyString::find(const char* str2) const{
	int b = strlen(str2);
	int i = 0, j = 0;
	while (i <len && j < b)
	{
		if (str[i] == str2[j])
		{
			i++;
			j++;
		}
		else
		{
			i = i - j + 1;
			j = 0;
		}
	}
	if (j = b)
		return i - b;
	else
		return 0;
}

const char* MyString::c_string() const {
	return str;
}