/*******************************************************************************
* FileName:         LinkStack.cpp
* Author:           �ſ�Ϊ
* Student Number:   3019244121
* Date:             2020/03/04 11:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #4
*******************************************************************************/


#include "LinkStack.h"
#include <cstddef>


LinkStack::LinkStack() {
	head = NULL;
	length = 0;
}
LinkStack::~LinkStack() {
	for (int i = 0; i < length-1; i++)
	{
		StackNode* temp;
		temp = head;
		head = head->next;
		delete temp;
	}
}

void LinkStack::push_back(int data) {
	if (head == NULL||length==0)
	{
		 head = new StackNode;
		head->value = data;
	}
	else
	{
		StackNode* temp;
		temp = head;
		for (int i = 0; i < length-1; i++)
		{
			temp = temp->next;
		}
		temp->next = new StackNode;
		temp->next->value = data;
		temp = NULL;
	}
	length++;
}

int LinkStack::top() const {
	StackNode* temp;
	temp = head;
	for (int i = 0; i < length-1; i++)
	{
		temp = temp->next;
	}
	return temp->value;
}

void LinkStack::pop() {
	if (head == NULL)
		return;
	else
	{
		StackNode* temp;
		temp = head;
		for (int i = 0; i < length-1; i++)
		{
			temp = temp->next;
		}
		delete temp;
		length--;
	}
}