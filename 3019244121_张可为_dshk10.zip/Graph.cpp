/*******************************************************************************
* FileName:         Graph.cpp
* Author:           �ſ�Ϊ
* Student Number:   3019244121
* Date:             2020/04/14 09:24:55
* Version:          v1.0
* Description:      Data Structure Experiment #10
*******************************************************************************/

#include "Graph.h"
#include <cstddef>


Graph::Graph(int v) {
    max_v = v;
    graph2 = new Vex[max_v + 1];//������Ⱥͳ���
    graph3 = new VertexNode[max_v + 1];//����ͷ�ڵ�
    for (int i = 1; i < max_v + 1; i++)
    {
        graph3[i].firstAdj = NULL;
        graph3[i].data = i;
    }
}

Graph::~Graph() {
    delete[] graph2;
    delete[] graph3;
}

void Graph::addedge(int s, int t, int w) {
    EdgeNode* newEdge = new EdgeNode;
    newEdge->link = NULL;
    newEdge->dest = t;
    newEdge->cost = w;
    graph3[s].data = s;
    graph3[t].data = t;
    graph2[s].outdegree++;
    graph2[t].indegree++;
    if (graph3[s].firstAdj == NULL)
    {
        graph3[s].firstAdj = newEdge;
    }
    else
    {
        EdgeNode* temp = graph3[s].firstAdj;
        while (temp->link != NULL)
        {
            temp = temp->link;
        }
        temp->link = newEdge;
    }
}

int Graph::getInDegree(int v) {
    return graph2[v].indegree;
}

int Graph::getOutDegree(int v) {
    return graph2[v].outdegree;
}

int Graph::access(int s, int t) {
    int result;
    if (graph2[s].outdegree == 0)
        return -1;
    else
    {
        EdgeNode* temp = graph3[s].firstAdj;
        do
        {
            if (temp->dest == t)
                result = temp->cost;
            else
                temp = temp->link;
        } while (temp->link != NULL);
    }
    return result;
}